import 'package:flutter/material.dart';

class pegawaipage extends StatefulWidget {
  const pegawaipage({super.key});

  @override
  State<pegawaipage> createState() => _pegawaipageState();
}

class _pegawaipageState extends State<pegawaipage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Data Pegawai")),
      body: ListView(
        children: const [
          Card(
            child: ListTile(
              title: const Text("Sandy Virdian"),
            ),
          ),
          Card(
            child: ListTile(
              title: const Text("Bill Gates"),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Mark Zuckerberg"),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Elon Musk"),
            ),
          ),
          Card(
            child: ListTile(
              title: Text("Jeff Bezos"),
            ),
          )
        ],
      ),
    );
  }
}
